const wagePerDay = 540;
const otRatePerHour = 84.37;
let users = [];
let currentUser = null;

// load from localStorage
if (localStorage.getItem("users")) {
  users = JSON.parse(localStorage.getItem("users"));
}

// UI helpers
function toggleSignUp() {
  const login = document.getElementById("login-section");
  const signup = document.getElementById("signup-section");
  login.style.display = login.style.display === "none" ? "block" : "none";
  signup.style.display = signup.style.display === "none" ? "block" : "none";
}

function login() {
  const u = document.getElementById("username").value.trim();
  const p = document.getElementById("password").value;
  if (!u || !p) return alert("Enter username and password");
  currentUser = users.find(o => o.username === u && o.password === p);
  if (!currentUser) {
    return alert("Invalid credentials");
  }
  showDashboard();
}

function signUp() {
  const u = document.getElementById("new-username").value.trim();
  const p = document.getElementById("new-password").value;
  if (!u || !p) return alert("Fill both fields");
  if (users.some(o => o.username === u)) return alert("Username exists");
  currentUser = {
    username: u,
    password: p,
    records: {} // keyed by cutoffKey, each has day info
  };
  users.push(currentUser);
  persist();
  showDashboard();
}

function showDashboard() {
  document.getElementById("login-section").style.display = "none";
  document.getElementById("signup-section").style.display = "none";
  document.getElementById("dashboard").style.display = "block";
  document.getElementById("user-name").innerText = currentUser.username;
  renderCutoff();
}

// Determine cutoff range based on selection
function getCutoffRange() {
  const radio = document.querySelector('input[name="cutoff"]:checked').value;
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth(); // 0-based
  if (radio === "first") {
    return { start: new Date(year, month, 1), end: new Date(year, month, 15) };
  } else {
    const lastDay = new Date(year, month + 1, 0).getDate();
    return { start: new Date(year, month, 16), end: new Date(year, month, lastDay) };
  }
}

// key to store per period per user
function cutoffKey() {
  const now = new Date();
  const month = now.getMonth() + 1; // 1-based
  const year = now.getFullYear();
  const part = document.querySelector('input[name="cutoff"]:checked').value; // "first" or "second"
  return `${year}-${String(month).padStart(2,"0")}-${part}`;
}

function renderCutoff() {
  const { start, end } = getCutoffRange();
  const tbody = document.getElementById("calendar-body");
  tbody.innerHTML = "";

  const key = cutoffKey();
  if (!currentUser.records[key]) {
    // initialize days
    currentUser.records[key] = {};
    for (let d = start.getDate(); d <= end.getDate(); d++) {
      currentUser.records[key][d] = { ot: 0, status: "working" };
    }
    persist();
  }

  for (let d = start.getDate(); d <= end.getDate(); d++) {
    const dayObj = currentUser.records[key][d];
    const row = document.createElement("tr");
    const dateObj = new Date(start.getFullYear(), start.getMonth(), d);
    const formatted = `${dateObj.getFullYear()}-${String(dateObj.getMonth()+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`;
    row.innerHTML = `
      <td>Day ${d}</td>
      <td>${formatted}</td>
      <td>
        <input type="number" min="0" step="0.25" value="${dayObj.ot}" data-day="${d}" class="ot-input" ${dayObj.status==="absent" ? "disabled" : ""}/>
      </td>
      <td>
        <select data-day="${d}" class="status-select">
          <option value="working" ${dayObj.status==="working" ? "selected" : ""}>Working</option>
          <option value="absent" ${dayObj.status==="absent" ? "selected" : ""}>N/A</option>
        </select>
      </td>
    `;
    tbody.appendChild(row);
  }

  // attach listeners
  document.querySelectorAll(".ot-input").forEach(inp => {
    inp.addEventListener("input", e => {
      const day = e.target.dataset.day;
      const val = parseFloat(e.target.value) || 0;
      const key = cutoffKey();
      currentUser.records[key][day].ot = val;
      persist();
      computeSummary();
    });
  });
  document.querySelectorAll(".status-select").forEach(sel => {
    sel.addEventListener("change", e => {
      const day = e.target.dataset.day;
      const val = e.target.value;
      const key = cutoffKey();
      currentUser.records[key][day].status = val;
      // if absent, clear ot and disable input
      if (val === "absent") {
        currentUser.records[key][day].ot = 0;
      }
      persist();
      renderCutoff(); // re-render to reflect disabled/cleared
      computeSummary();
    });
  });

  computeSummary();
}

function computeSummary() {
  const key = cutoffKey();
  const record = currentUser.records[key];
  let workingDays = 0;
  let totalOT = 0;
  for (const d in record) {
    if (record[d].status === "working") {
      workingDays += 1;
      totalOT += parseFloat(record[d].ot) || 0;
    }
  }
  const base = workingDays * wagePerDay;
  const otPay = totalOT * otRatePerHour;
  const totalWage = base + otPay;

  document.getElementById("working-days").innerText = workingDays;
  document.getElementById("total-ot").innerText = totalOT.toFixed(2);
  document.getElementById("total-wage").innerText = totalWage.toFixed(2);
}

function logout() {
  currentUser = null;
  document.getElementById("dashboard").style.display = "none";
  document.getElementById("login-section").style.display = "block";
  document.getElementById("username").value = "";
  document.getElementById("password").value = "";
}

function resetData() {
  if (!currentUser) return;
  if (!confirm("Reset all data for this user in current cutoff? This will clear recorded OT/status for this period.")) return;
  const key = cutoffKey();
  delete currentUser.records[key];
  persist();
  renderCutoff();
}

// persist to localStorage
function persist() {
  localStorage.setItem("users", JSON.stringify(users));
}